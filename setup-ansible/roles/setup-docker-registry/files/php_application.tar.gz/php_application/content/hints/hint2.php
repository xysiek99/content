<?php
        include '../includes/hintheader.php';
?>
<div class="container">
	<div>
		<br>
		<h3>Pliki do pobrania:</h3>
		<a class="btn btn-primary" href="/files/Pliki - Lab2.rar" download>Pliki - Lab2.rar</a>
	</div>
	<hr>
	<div>
	<div>
		<h2>ZADANIE 1: KROK 1</h2>
		<div>
			<img class="img-fluid" src="/img/lab2Zoiper3 2 konta.PNG">
			<p>Powyższy zrzut ekranu pokazuje konfigurację dwóch kont w pliku sip.conf</p>
		</div>
		<hr>
		<h2>ZADANIE 1: KROK 2</h2>
		<div>
			<img class="img-fluid" src="/img/lab2Zoiper.PNG">
			<p>Zoiper</p>
			<br>
			<img class="img-fluid" src="/img/lab2blink.PNG">
			<p>Blink</p>
		</div>
		<hr>
	</div>
	<div>
		<h2>ZADANIE 2 KROK 1</h2>
		<div>
			<img class="img-fluid" src="/img/lab2ZAD2 KROK 1.PNG">
		</div>
		<hr>
		<h2>ZADANIE 2: KROK 2</h2>
		<div>
			<img class="img-fluid" src="/img/lab2Zoiper3 2 konta.PNG">
		</div>
		<hr>
		<h2>ZADANIE 2: KROK 3</h2>
		<div>
			<img class="img-fluid" src="/img/lab2DIALPLAN SHOW.PNG">
			<p>Po przeładowaniu widać dodane sekcje.</p>
		</div>
		<hr>
		<h2>ZADANIE 2: KROK 4</h2>
		<div>
			<img class="img-fluid" src="/img/lab2zoiper to blink.PNG">
			<img class="img-fluid" src="/img/lab2blink to zoiper.PNG">
		</div>
		<hr>
	</div>
	<div>
		<h2>ZADANIE 3 KROK 2</h2>
		<div>
			<img class="img-fluid" src="/img/lab2SDP.PNG">
			<p>SDP</p>
			<img class="img-fluid" src="/img/lab2CallID dzwoniącego.PNG">
			<p>Call-ID dzwoniącego</p>
			<img class="img-fluid" src="/img/lab2CallID odbierającego.PNG">
			<p>Call-ID odbierającego</p>
			<br>
			<p><strong>Adres IP i port z sekcji SDP</strong></p>
			<p>Maszyna z terminalami – 192.168.31.203</p>
			<p>Maszyna z centralą Asterisk – 192.168.31.202</p>
			<br>
			<img class="img-fluid" src="/img/lab2kodeki.PNG">
			<br>
			<p><strong>Użyte kodeki:</strong></p>
			<img class="img-fluid" src="/img/lab2kodeki2.PNG">
			<p>Połączenie zostało wykonane z użyciem kodeka PCMU, który działa na porcie 50008.</p>
		</div>
		<hr>
	</div>
	<div>
		<h2>ZADANIE 4 KROK 2</h2>
		<div>
			<img class="img-fluid" src="/img/lab2allow.PNG">
		</div>
		<hr>
		<h2>ZADANIE 4 KROK 3</h2>
		<div>
			<img class="img-fluid" src="/img/lab2pcma.PNG">
		</div>
	</div>
</div>

<?php
    include '../includes/footer.php';
?>
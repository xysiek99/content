<?php
        include '../includes/hintheader.php';
?>
<div class="container">
	<div>
		<br>
		<h3>Pliki do pobrania:</h3>
		<a class="btn btn-primary" href="/files/Pliki - Lab3.rar" download>Pliki - Lab3.rar</a>
	</div>
	<hr>
	<div>
	<div>
		<h2>ZADANIE 1: KROK 3</h2>
		<div>
			<img class="img-fluid" src="/img/lab3[bez_rej]sipConf maszyna1.PNG">
			<p>Ustawienia sip.conf na maszynie nr 1.</p>
			<br>
			<img class="img-fluid" src="/img/lab3[bez_rej]sipConf maszyna2.PNG">
			<p>Ustawienia sip.conf na maszynie nr 2.</p>
		</div>
		<hr>
	</div>
	<div>
		<h2>ZADANIE 2 KROK 1</h2>
		<div>
			<img class="img-fluid" src="/img/lab3[bez_rej]extensionsConf maszyna1.png">
		</div>
		<hr>
		<h2>ZADANIE 2: KROK 2</h2>
		<div>
			<img class="img-fluid" src="/img/lab3[bez_rej]extensionsConf maszyna2.png">
		</div>
		<hr>
		<h2>ZADANIE 2: KROK 4</h2>
		<div>
			<img class="img-fluid" src="/img/lab3[bez_rej]dzwonienie zoiper to blink.PNG">
		</div>
		<hr>
		<h2>ZADANIE 2: KROK 5</h2>
		<div>
			<img class="img-fluid" src="/img/lab3[bez_rej]dzwonienie blink to zoiper.PNG">
		</div>
		<hr>
	</div>
	<div>
		<h2>ZADANIE 3 KROK 1</h2>
		<div>
			<img class="img-fluid" src="/img/lab3[z_rej]sipConf maszyna1.PNG">
		</div>
		<hr>
		<h2>ZADANIE 3 KROK 2</h2>
		<div>
			<img class="img-fluid" src="/img/lab3[z_rej]sipConf maszyna2.PNG">
		</div>
		<hr>
		<h2>ZADANIE 3 KROK 3</h2>
		<div>
			<img class="img-fluid" src="/img/lab3[z_rej]extensionsConf maszyna1.PNG">
		</div>
		<hr>
		<h2>ZADANIE 3 KROK 4</h2>
		<div>
			<img class="img-fluid" src="/img/lab3[z_rej]extensionsConf maszyna2.PNG">
		</div>
		<hr>
		<h2>ZADANIE 3 KROK 5</h2>
		<div>
			<img class="img-fluid" src="/img/lab3[z_rej]rejestracja1000.PNG"><br><br>
			<img class="img-fluid" src="/img/lab3[z_rej]centrala1.PNG"><br><br>
			<img class="img-fluid" src="/img/lab3[z_rej]centrala2.PNG"><br><br>
			<img class="img-fluid" src="/img/lab3[z_rej]terminal.PNG">
		</div>
		<hr>
		<h2>ZADANIE 3 KROK 6</h2>
		<div>
			<img class="img-fluid" src="/img/lab3[z_rej]dzwonienie1000-1001.PNG">
		</div>
	</div>
</div>

<?php
    include '../includes/footer.php';
?>
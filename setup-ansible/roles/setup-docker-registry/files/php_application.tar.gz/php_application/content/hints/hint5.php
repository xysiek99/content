<?php
        include '../includes/hintheader.php';
?>
<div class="container">
	<div>
		<br>
		<h3>Pliki do pobrania:</h3>
		<a class="btn btn-primary" href="/files/Pliki - Lab5.rar" download>Pliki - Lab5.rar</a>
	</div>
	<hr>
	<div>
	<div>
		<h2>ZADANIE 1: KROK 1</h2>
		<div>
			<img class="img-fluid" src="/img/lab5zad1 krok1.PNG">
		</div>
		<hr>
		<h2>ZADANIE 1: KROK 2</h2>
		<div>
			<img class="img-fluid" src="/img/lab5zad1 krok2.PNG">
		</div>
		<hr>
		<h2>ZADANIE 1: KROK 3a</h2>
		<div>
			<img class="img-fluid" src="/img/lab5zad1 krok3a.PNG">
		</div>
		<hr>
		<h2>ZADANIE 1: KROK 3b</h2>
		<div>
			<img class="img-fluid" src="/img/lab5zad1 krok3b.PNG">
		</div>
		<hr>
		<h2>ZADANIE 1: KROK 3c</h2>
		<div>
			<img class="img-fluid" src="/img/lab5zad1 krok3c.PNG">
		</div>
		<hr>
	</div>
	<div>
		<h2>ZADANIE 2 KROK 2</h2>
		<div>
			<img class="img-fluid" src="/img/lab5zad2 krok2.PNG">
		</div>
		<hr>
	</div>
	<div>
		<h2>ZADANIE 3</h2>
		<div>
			<img class="img-fluid" src="/img/lab5zad3.PNG">
		</div>
		<hr>
	</div>
	<div>
		<h2>ZADANIE 4 KROK 1</h2>
		<div>
			<img class="img-fluid" src="/img/lab5zad4 krok1.PNG">
		</div>
		<hr>
		<h2>ZADANIE 4 KROK 2</h2>
		<div>
			<img class="img-fluid" src="/img/lab5zad4 krok2.PNG">
		</div>
		<hr>
		<h2>ZADANIE 4 KROK 4</h2>
		<div>
			<img class="img-fluid" src="/img/lab5zad4 krok4.PNG">
		</div>
	</div>
</div>

<?php
    include '../includes/footer.php';
?>
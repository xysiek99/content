<?php
        include '../includes/hintheader.php';
?>
<div class="container">
	<div>
		<br>
		<h3>Pliki do pobrania:</h3>
		<a class="btn btn-primary" href="/files/Pliki - Lab6.rar" download>Pliki - Lab6.rar</a>
	</div>
	<hr>
	<div>
	<div>
		<h2>ZADANIE 1: KROK 1</h2>
		<div>
			<img class="img-fluid" src="/img/lab6zad1 krok1.PNG">
		</div>
		<hr>
		<h2>ZADANIE 1: KROK 2</h2>
		<div>
			<img class="img-fluid" src="/img/lab6zad1 krok2.PNG">
		</div>
		<hr>
		<h2>ZADANIE 1: KROK 3</h2>
		<div>
			<img class="img-fluid" src="/img/lab6zad1 krok3.PNG">
		</div>
		<hr>
		<h2>ZADANIE 1: KROK 5</h2>
		<div>
			<img class="img-fluid" src="/img/lab6zad1 krok5.PNG">
		</div>
		<hr>
	</div>
	<div>
		<h2>ZADANIE 2 KROK 2</h2>
		<div>
			<img class="img-fluid" src="/img/lab6zad2 krok2.PNG">
		</div>
		<hr>
		<h2>ZADANIE 2 KROK 3</h2>
		<div>
			<img class="img-fluid" src="/img/lab6zad2 krok3.PNG">
		</div>
		<hr>
		<h2>ZADANIE 2 KROK 4</h2>
		<div>
			<img class="img-fluid" src="/img/lab6zad2 krok4.PNG">
		</div>
		<p>Sequence = 23 </p>
		<p>SSRC (Our Synchronization Source identifier) - 1398536225 </p>
		<p>Themssrc (Their Synchronization Source identifier) = 695874074079 </p>
		<p>Lp (Our lost packet count) = 0 </p>
		<p>Rxjitter (Received packet jitter) - 0 </p>
		<p>Txjitter (Transmitted packet jitter) - 0.000510</p>
		<p>Rxcount – liczba bajtow odebranych = 410 bajtow</p>
		<p>Txcount – liczba bajtow nadanych = 398 bajtow</p>
		<p>Rtt = round trip time = 0.001953</p>
	</div>
</div>

<?php
    include '../includes/footer.php';
?>
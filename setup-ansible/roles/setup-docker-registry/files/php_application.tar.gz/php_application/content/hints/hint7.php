<?php
        include '../includes/hintheader.php';
?>
<div class="container">
	<div>
		<h2>ZADANIE 1: KROK 1</h2>
		<div>
			<img class="img-fluid" src="/img/lab7zad1 krok1.PNG"><br><br>
			<img class="img-fluid" src="/img/lab7zad1 krok1b.PNG">
		</div>
		<hr>
		<h2>ZADANIE 1: KROK 2</h2>
		<div>
			<img class="img-fluid" src="/img/lab7zad1 krok2.PNG">
		</div>
		<hr>
	</div>
	<div>
		<h2>ZADANIE 2 KROK 1</h2>
		<div>
			<img class="img-fluid" src="/img/lab7zad2 krok1.PNG">
		</div>
		<hr>
		<h2>ZADANIE 2 KROK 2</h2>
		<div>
			<img class="img-fluid" src="/img/lab7zad2 krok2.PNG">
		</div>
		<hr>
		<h2>ZADANIE 2 KROK 3</h2>
		<div>
			<img class="img-fluid" src="/img/lab7zad2 krok3.PNG">
		</div>
		<hr>
		<h2>ZADANIE 2 KROK 4</h2>
		<div>
			<img class="img-fluid" src="/img/lab7zad2 krok4.PNG">
		</div>
		<hr>
		<h2>ZADANIE 2 KROK 5</h2>
		<div>
			<img class="img-fluid" src="/img/lab7zad2 krok5.PNG">
		</div>
	</div>
</div>

<?php
    include '../includes/footer.php';
?>
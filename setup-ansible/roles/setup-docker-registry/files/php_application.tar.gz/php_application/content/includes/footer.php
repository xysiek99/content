</body>
<footer>
	<div class="card-footer text-muted">
		<div >
			<p>© 2021 VoIP Team. All rights reserved.</p>
		</div>
	</div>
</footer>
<!-- Jquery first, then JavaScript -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.3.1/jspdf.umd.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.2/jspdf.debug.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
		<script type="text/javascript" src="./js/script.js"></script>
        <script src="/js/jquery-3.1.0.min.js"></script>
        <script src="/js/jquery.waypoints.min.js"></script>
        <script src="/js/wow.min.js"></script>
        <script src="/js/main.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
</html>
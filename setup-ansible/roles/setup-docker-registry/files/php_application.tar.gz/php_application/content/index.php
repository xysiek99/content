<?php
    require_once 'includes/db.php';
?>
<?php
    include($SERVER["DOCUMENT_ROOT"].'includes/header.php');
?>
    <div id="content-container">
        <div id="container-id-22-" data-element-type="section">
            <div id="container-id-17-" data-element-type="container">
                <div id="container-id-11-" data-element-type="container">
                    <div id="container-id-1-" data-element-type="container">
                        <p id="text-id-13-" data-element-type="text"></p>
                        <p id="text-id-2-" data-element-type="text">Aplikacja wspomagająca naukę konfiguracji usług telefonii pakietowej w centrali Asterisk.</p>
                    </div>
                    <div id="container-id-6-" data-element-type="container"></div>
                </div>
                <a id="image-id-20-" data-element-type="image">
                    <img id="element-id-21-" src="/img/main_page_picture.PNG">
                </a>
            </div>
        </div>
        <div id="container-id-3-" data-element-type="section">
            <div id="container-id-20-" data-element-type="container">
                <div id="container-id-28-" data-element-type="container">
                    <div id="container-id-0-" data-element-type="container">
                        <p id="text-id-25-" data-element-type="text">Laboratoria</p>
                        <p id="text-id-27-" data-element-type="text">
                            <span id="element-id-109-">Każde laboratorium posiada wprowadzenie, zdefiniowane cele, zadania do wykonania z instrukcją "krok po kroku", zadania do samodzielnej pracy, moduł analizy, bazę wiedzy problemów i zakończone jest quizem sprawdzającym wiedzę.</span>
                        </p>
                    </div>
                </div>
                <div id="section-id-15-" data-element-type="section" contenteditable="false">
                    <div id="container-id-4-" data-element-type="container">
                        <div id="container-id-5-" data-element-type="container">
                            <div id="container-id-2-" data-element-type="container">
                                <a href="./labs/lab1.php">
                                    <p id="text-id-6-" data-element-type="text">Laboratorium 1</p>
                                    <p id="text-id-8-" data-element-type="text">Rejestracja terminali w centrali Asterisk</p>
                                </a>
                            </div>
                        </div>
                        <div id="container-id-25-" data-element-type="container">
                            <div id="container-id-21-" data-element-type="container">
                                <a href="./labs/lab2.php">
                                    <p id="text-id-22-" data-element-type="text">Laboratorium 2</p>
                                    <p id="text-id-24-" data-element-type="text">Konfiguracja i wykonywanie połączeń lokalnych</p>
                                </a>
                            </div>
                        </div>
                        <div id="container-id-42-" data-element-type="container">
                            <div id="container-id-38-" data-element-type="container">
                                <a href="./labs/lab3.php">
                                    <p id="text-id-39-" data-element-type="text">Laboratorium 3</p>
                                    <p id="text-id-41-" data-element-type="text">Konfiguracja i wykonywanie połączeń między centralami</p>
                                </a>
                            </div>
                        </div>
                        <div id="container-id-189-" data-element-type="container">
                            <div id="container-id-185-" data-element-type="container">
                                <a href="./labs/lab4.php">
                                    <p id="text-id-186-" data-element-type="text">Laboratorium 4</p>
                                    <p id="text-id-188-" data-element-type="text">Auto Attendant, Interactive Voice Response, VoiceMail</p>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="section-id-151-" data-element-type="section" contenteditable="false">
                    <div id="container-id-131-" data-element-type="container">
                        <div id="container-id-132-" data-element-type="container">
                            <div id="container-id-135-" data-element-type="container">
                                <a href="./labs/lab5.php">
                                    <p id="text-id-136-" data-element-type="text">Laboratorium 5</p>
                                    <p id="text-id-137-" data-element-type="text">Auto Attendant, Interactive Voice Response, VoiceMail</p>
                                </a>
                            </div>
                        </div>
                        <div id="container-id-138-" data-element-type="container">
                            <div id="container-id-141-" data-element-type="container">
                                <a href="./labs/lab6.php">
                                    <p id="text-id-142-" data-element-type="text">Laboratorium 6</p>
                                    <p id="text-id-143-" data-element-type="text">Rekordy CDR</p>
                                </a>
                            </div>
                        </div>
                        <div id="container-id-144-" data-element-type="container">
                            <div id="container-id-147-" data-element-type="container">
                                <a href="./labs/lab7.php">
                                    <p id="text-id-148-" data-element-type="text">Laboratorium 7</p>
                                    <p id="text-id-150-" data-element-type="text">Diagnozowanie problemów</p>
                                </a>
                            </div>
                        </div>
						<div id="container-id-200-" data-element-type="container">
                            <div id="container-id-201-" data-element-type="container">
                                <a href="./labs/lab8.php">
                                    <p id="text-id-202-" data-element-type="text">Laboratorium 8</p>
                                    <p id="text-id-203-" data-element-type="text">Bezpieczeństwo telefonii pakietowej</p>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
    require_once 'includes/footer.php';
?>